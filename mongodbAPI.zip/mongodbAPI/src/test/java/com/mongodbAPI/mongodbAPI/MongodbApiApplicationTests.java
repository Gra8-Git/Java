package com.mongodbAPI.mongodbAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongodbApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
